import React, { Component } from 'react';

import { Column, Row } from 'simple-flexbox';
import { Panel, Image  } from 'react-bootstrap';

import BootstrapTable from 'react-bootstrap-table-next';
import cellEditFactory from 'react-bootstrap-table2-editor';
import paginationFactory from 'react-bootstrap-table2-paginator';
import { reduxForm, Field, SubmissionError } from 'redux-form';

import ProductsFormContainer from '../../containers/ProductsFormContainer';
import CollapsePanel from './CollapsePanel';


const columns = [{
  dataField: '_id',
  text: 'Product ID'
}, {
  dataField: 'name',
  text: 'Product Name'
}, {
  dataField: 'price',
  text: 'Product Price'
}];



  class ProductsList extends React.Component {
	
	constructor(props) {
		super(props);
		this.deleteSelected = this.deleteSelected.bind(this);
	}
		
	componentDidMount() {
		this.props.fetchProducts();
	}
	
	deleteSelected(){
		debugger;
		this.props.deleteProduct(this.props.selected);
	}
  
	 
	render(){
		const { products, error, loading  } = this.props.productsList;
		if (loading) {
		  return <div>Loading...</div>;
		}
		if (error) {
		  return <div>Loading error...</div>;
		}

		return (
			<div>
				
				<CollapsePanel>
					<Row vertical='center'>
						<Column flexGrow={1} horizontal='center'>
							<ProductsFormContainer 	token={this.props.token}/>
						</Column>
						<Column flexGrow={1} horizontal='center'>
							<Panel bsStyle="success">
								<Image width={70} height={70}
								  src='..\..\..\public\img\products\default.png'
								  
								/>
							</Panel>
						</Column>
					</Row>	
				</CollapsePanel>
				
				<button type="button" class="btn btn-info" onClick={this.deleteSelected}>Supprimer</button>
				
					<BootstrapTable 
						 //pagination={ paginationFactory()}
						keyField='_id' 
						data={  this.props.productsList.products }
						columns={ columns }
						cellEdit =  {cellEditFactory({mode: "click", blurToSave: true, afterSaveCell: this.props.onAfterSaveCell })}
						selectRow={ 
									{
										mode: 'radio',
										selected:this.props.selected._id,
										clickToSelect: true,
										clickToEdit: true ,
										classes: 'selection-row',
										style: { backgroundColor: '#c8e6c9' },
										onSelect: this.props.onSelectRow
									} }
					/>
				
				
			 </div>
		);
	}
}



export default ProductsList;