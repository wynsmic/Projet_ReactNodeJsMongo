### Hello Roland
Ce projet est un chantier récent, ne t'attends pas à une plateforme finie et intuitive, ce n'est pas tant le but.
Dans cette version qui est plus pédagogique (et qui pourra peut être servir à ma copine si ça la branche), tu trouves:
 - Un coté backend pour interraction avec MongoDB
 - Des prémisses de fonctionalité drag & drop qui serviraient à une UX originale
 - Quelques modules importés  de git (tableaux éditables, panels etc...) pour faire joujou
 


### Configuration
- **Platform:** node
- **Framework**: express
- **Template Engine**: jade
- **CSS Framework**: bootstrap
- **CSS Preprocessor**: less
- **JavaScript Framework**: react
- **Build Tool**: gulp
- **Unit Testing**: mocha
- **Database**: mongodb
- **Authentication**: google,email,facebook
- **Deployment**: heroku


### Lancement

Dans une console depuis depuis le rep bin de mongo :
$ mongod

Dans une console depuis depuis la app root:
$ npm install
$ npm start

Si besoin de faire un init de la batabase, revenir vers moi 


