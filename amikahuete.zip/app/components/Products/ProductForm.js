
import React, { Component, PropTypes } from 'react';
import { Link } from 'react-router';

import { Form, FormGroup, ControlLabel, FormControl, Checkbox, InputGroup, Col, Button, Glyphicon   } from 'react-bootstrap';


////////////// to uninstall
import { reduxForm, Field, SubmissionError } from 'redux-form';
import Input from 'react-input-datalist';




class ProductsForm extends Component {

	renderError(fieldProducts) {
		if (fieldProducts && fieldProducts.error && fieldProducts.error.message) {
		  return (
			<div className="alert alert-danger">
			  { fieldProducts ? fieldProducts.error.message : '' }
			</div>
			);
		} else {
		  return <span></span>
		}
	}

  
  
  render() {
    const {handleSubmit, submitting, fieldProducts, token, handleChange} = this.props;
	const renderFields = fieldProducts.map( (item, i) => <option key={i} value={item.name}/>);
	
	
	// <FormControl.Feedback /> peut etre utile apres check de valeurs
    return (
      <div className='container'>
        { this.renderError(fieldProducts) }
			
		<Form onSubmit={this.props.handleSubmit}>
		
			<FormGroup controlId="name" >
				<ControlLabel>Produit</ControlLabel>
				<FormControl
					type="text"
					list="products"
					placeholder="Nom"
					onChange={handleChange}
				/>
				<datalist id="products">
					{renderFields}
				</datalist>
			</FormGroup>
			
			<FormGroup>
			  <Checkbox title="organicFlag" id="organicFlag">Bio</Checkbox>
			  <Checkbox title="labelRougeFlag" id="labelRougeFlag">Label rouge</Checkbox>
			  <Checkbox title="permacultreFlag" id="permacultreFlag">Issue de la permaculture</Checkbox>
			  <Checkbox title="sustainableFlag" id="sustainableFlag">Issu de l'agriculture raisonnée</Checkbox>
			  <Checkbox title="fullSunFlag" id="fullSunFlag">Plein sol</Checkbox>
			  <Checkbox title="frozenFlag" id="frozenFlag">Surgelé</Checkbox>
			</FormGroup>
			
			<FormGroup controlId="price" >
				<ControlLabel>Prix</ControlLabel>
				<FormControl
					type="text"
					placeholder="00.00"
					onChange={handleChange}
				/>
				 <FormControl.Feedback>
				  <Glyphicon glyph="euro" />
				</FormControl.Feedback>
			</FormGroup>
			
			<FormGroup controlId="quantity" >
				<ControlLabel>Quantité</ControlLabel>
				<FormControl
					type="text"
					placeholder=""
					onChange={handleChange}
				/>
			</FormGroup>
			
			<FormGroup>
				<Col smOffset={2} sm={10}>
				  <Button type="submit">Ajouter au stock</Button>
				</Col>
			</FormGroup>
			
		</Form>
      </div>
    )
  }
}


export default ProductsForm;