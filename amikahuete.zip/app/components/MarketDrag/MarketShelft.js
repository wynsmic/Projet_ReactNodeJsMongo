import React, { Component } from 'react';
import PropTypes from 'prop-types';

import { DragDropContext } from 'react-dnd';
import HTML5Backend from 'react-dnd-html5-backend';

import Board from './Board';
import Shelft from './Shelft';




class MarketShelft extends Component {
	
	constructor(props) {
		super(props);	
		this.handleClick = this.handleClick.bind(this);
	}
	
	
	handleClick(e){
		console.log('clicked.');
	}
	
	render(){
		return(
			<div>
				<Shelft 
					fetchProducts={this.props.fetchProducts}
					productsList={this.props.productsList}
					selectedProduct={this.props.selectedProduct}
				/>
				<Board
					productsSelection={this.props.productsSelection}
					updatePosition={this.props.updatePosition}
					selectedProduct={this.props.selectedProduct}
				/>
			</div>
		)  
	}
}

export default DragDropContext(HTML5Backend)(MarketShelft);